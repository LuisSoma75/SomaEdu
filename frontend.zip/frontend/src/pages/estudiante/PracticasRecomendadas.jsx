import React, { useEffect, useMemo, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./PracticasRecomendadas.css";

const API = (import.meta.env.VITE_API_URL || "http://localhost:3001").replace(/\/+$/, "");

export default function PracticasRecomendadas() {
  const navigate = useNavigate();

  // Auth del localStorage
  const auth = useMemo(() => {
    try { return JSON.parse(localStorage.getItem("auth") || "{}"); } catch { return {}; }
  }, []);
  const carne = auth.carne_estudiante ?? auth.carne ?? auth.id_usuario ?? null;

  const [loading, setLoading] = useState(true);
  const [items, setItems]     = useState([]);
  const [error, setError]     = useState("");

  const fetchJSON = useCallback(async (url, signal) => {
    const r = await fetch(url, {
      signal,
      credentials: "include",
      headers: { Accept: "application/json" }
    });
    let data = null;
    try { data = await r.json(); } catch {}
    if (!r.ok) {
      const msg = (data && (data.msg || data.message || data.error)) || `HTTP ${r.status}`;
      throw new Error(msg);
    }
    return data;
  }, []);

  useEffect(() => {
    const ac = new AbortController();
    (async () => {
      setLoading(true);
      setError("");

      try {
        if (!carne) {
          throw new Error("No se detectó el identificador del estudiante (carne). Vuelve a iniciar sesión.");
        }

        // Probamos varios endpoints razonables
        const urls = [
          `${API}/api/estudiante/practicas/recomendadas?carne=${encodeURIComponent(String(carne))}`,
          `${API}/api/estudiante/recomendadas?carne=${encodeURIComponent(String(carne))}`,
          `${API}/api/adaptative/recommendations?carne=${encodeURIComponent(String(carne))}`,
        ];

        for (const u of urls) {
          try {
            const j = await fetchJSON(u, ac.signal);
            const arr = (j.items || j.data || j || []);
            const norm = arr.map(n => ({
              id: n.id || n.id_rec || n.id_practica || n.id_pregunta || Math.random().toString(36).slice(2),
              titulo: n.titulo || n.nombre || n.enunciado || "Práctica",
              area: n.area || n.nombre_area || n.nombreTema || "Área",
              valor: Number(n.valor ?? n.Valor ?? n.prioridad ?? 0),
              dificultad: n.dificultad ?? n.nivel ?? null,
              id_pregunta: n.id_pregunta ?? null,
              id_materia: n.id_materia ?? null,
              id_estandar: n.id_estandar ?? null,
            }));

            if (norm.length) {
              setItems(norm);
              setLoading(false);
              return;
            }
          } catch {
            // intenta siguiente URL
          }
        }

        // Si ninguno respondió con datos
        setItems([]);
      } catch (e) {
        setError(e.message || "No se pudieron cargar recomendaciones.");
      } finally {
        setLoading(false);
      }
    })();

    return () => ac.abort();
  }, [API, carne, fetchJSON]);

  return (
    <div className="page practicas" data-page="practicas">
      {/* HEADER oscuro (ya no hay bloque blanco) */}
      <section className="prc-hero">
        <h1 className="prc-title">Prácticas recomendadas</h1>
        <p className="prc-sub">Sugerencias personalizadas para reforzar tus áreas.</p>
      </section>

      {loading && <div className="prc-skeleton">Cargando recomendaciones…</div>}

      {error && <div className="prc-alert prc-alert-error">{error}</div>}

      {!loading && !error && items.length === 0 && (
        <div className="prc-empty">
          Por ahora no hay recomendaciones disponibles. Completa una evaluación para generarlas.
        </div>
      )}

      {!loading && !error && items.length > 0 && (
        <section className="prc-grid">
          {items.map((it) => (
            <article key={it.id} className="prc-card">
              <header className="prc-card-head">
                <span className="prc-chip">{it.area}</span>
                {Number.isFinite(it.valor) && <span className="prc-badge">Prioridad {it.valor}</span>}
              </header>

              <h3 className="prc-card-title">{it.titulo}</h3>

              {it.dificultad && (
                <div className="prc-card-foot">
                  <span className="prc-badge">Dificultad: {String(it.dificultad)}</span>
                </div>
              )}

              <footer className="prc-card-foot">
                {it.id_materia ? (
                  <button
                    className="prc-btn"
                    title="Practicar ahora"
                    onClick={() => {
                      // Puedes afinar la ruta si tienes un flujo por estándar/pregunta
                      // Ej.: navigate(`/estudiante/resolver/${it.id_materia}?std=${it.id_estandar||""}&qid=${it.id_pregunta||""}`)
                      navigate(`/estudiante/resolver/${it.id_materia}`);
                    }}
                  >
                    Practicar ahora
                  </button>
                ) : (
                  <button className="prc-btn" disabled title="Aún no conectado a un flujo de práctica">
                    Ver detalle
                  </button>
                )}
              </footer>
            </article>
          ))}
        </section>
      )}
    </div>
  );
}
