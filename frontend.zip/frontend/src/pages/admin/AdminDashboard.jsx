export default function AdminDashboard() {
  return <h1>Bienvenido Administrador</h1>;
}
